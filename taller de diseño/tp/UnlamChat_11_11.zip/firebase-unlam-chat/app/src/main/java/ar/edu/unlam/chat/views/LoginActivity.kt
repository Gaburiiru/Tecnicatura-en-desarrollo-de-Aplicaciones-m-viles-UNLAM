package ar.edu.unlam.chat.views

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import ar.edu.unlam.chat.databinding.ActivityLoginBinding
import ar.edu.unlam.chat.entities.User
import ar.edu.unlam.chat.services.UserService
import ar.edu.unlam.chat.services.impl.UserServiceImpl
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract
import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging

class LoginActivity : AppCompatActivity() {
    private var db = FirebaseFirestore.getInstance()

    private lateinit var binding: ActivityLoginBinding
    private val userService: UserService = UserServiceImpl

    private val signInLauncher = registerForActivityResult(
        FirebaseAuthUIActivityResultContract()
    ) { res ->
        this.onSignInResult(res)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (isSignedIn()) {
            goToMain()
            return
        }

        createSignInIntent()

// Create a new user with a first and last name

        val user = hashMapOf(
            "first" to "Ada",
            "last" to "Lovelace",
            "born" to 1815
        )

// Add a new document with a generated ID
        db.collection("users")
            .add(user)
            .addOnSuccessListener { documentReference ->
                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error adding document", e)
            }
    }

    private fun createSignInIntent() {
        val providers = arrayListOf(
            AuthUI.IdpConfig.EmailBuilder().build(),
            AuthUI.IdpConfig.PhoneBuilder().build(),
            AuthUI.IdpConfig.GoogleBuilder().build()
        )
        val signInIntent = AuthUI.getInstance()
            .createSignInIntentBuilder()
            .setAvailableProviders(providers)
            .build()

        signInLauncher.launch(signInIntent)
    }

    private fun onSignInResult(result: FirebaseAuthUIAuthenticationResult) {
        val response = result.idpResponse
        if (result.resultCode == RESULT_OK) {
            goToMain()
            return
        }

        response?.error?.message?.let { error ->
            Snackbar.make(binding.root, error, Snackbar.LENGTH_LONG).show()
        }
        createSignInIntent()
    }

    private fun goToMain() {
        FirebaseAuth.getInstance().currentUser?.let {
            userService.save(User(it.uid, it.displayName, it.email, it.phoneNumber))

        }
        FirebaseMessaging.getInstance().token.addOnSuccessListener {
            Log.d(TAG, "token for user request with id $it")
            userService.updateToken(it)
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun isSignedIn() = FirebaseAuth.getInstance().currentUser != null

    companion object {
        val TAG = LoginActivity::class.simpleName
    }
}