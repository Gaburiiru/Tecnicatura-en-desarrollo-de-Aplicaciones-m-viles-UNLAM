package ar.edu.unlam.chat.services

import ar.edu.unlam.chat.entities.Conversation
import ar.edu.unlam.chat.entities.Message

interface ConversationService {
    fun startConversation(
        initiatorId: String,
        toUserId: String,
        text: String,
        onStarted: (String) -> Unit
    )

    fun connectToConversation(id: String, onUpdateConversation: (List<Message>) -> Unit)

    fun sendMessage(
        userId: String,
        conversationId: String,
        text: String
    )

    fun getUserConversations(id: String, onSuccess: (List<Conversation>) -> Unit)
}