package ar.edu.unlam.chat.views.adapters

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ar.edu.unlam.chat.databinding.ItemConversationBinding
import ar.edu.unlam.chat.entities.Conversation
import ar.edu.unlam.chat.utils.displayName
import ar.edu.unlam.chat.utils.isNotCurrentUser
import com.google.firebase.auth.FirebaseAuth
import java.util.*

class ConversationsListAdapter(
    private var conversations: List<Conversation>,
    private val onClick: (conversation: Conversation) -> Unit
) : RecyclerView.Adapter<ConversationsListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemConversationBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        with(holder) {
            with(conversations[position]) {
                participants.find { p -> isNotCurrentUser(p.id) }?.let {
                    binding.conversationTitle.text = it.displayName()
                }

                binding.conversationTimestamp.text = getDateString(lastModified.toDate())
                binding.conversationContainer.setOnClickListener {
                    this.let(onClick)
                }
            }
        }
    }

    private fun getDateString(date: Date): String {
        val today = Calendar.getInstance()
        val timeStamp = Calendar.getInstance()
        timeStamp.time = date

        if (today.get(Calendar.DATE) == timeStamp.get(Calendar.DATE)) {
            return DateFormat.format("h:mm aa", timeStamp).toString()
        }

        return DateFormat.format("dd/MM", timeStamp).toString()
    }

    override fun getItemCount() = conversations.size

    fun changeList(conversations: List<Conversation>){
        this.conversations = conversations
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ItemConversationBinding) : RecyclerView.ViewHolder(binding.root)


}