package ar.unlam.edu.ar;

public interface iCargable {

	Integer obtenerCantidadMaximaPasajero();
}
