package ar.edu.unlam.chat.services.messages

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers

import retrofit2.http.POST


/**
 * DISCLAIMER:
 * Esto no es un buena practica, el solo hecho de utilizar esta llamada a la api de firebase expone datos sensibles a un atacante
 * Recordemos que cualquier usuario puede descompilar un APK y por consecuencia obtener esta información
 */
interface MessageInterface {

    @Headers(
        "Authorization: key=AAAAZv2QEpA:APA91bHiy8cZTxtGWk6q8AlJnSYKXWwjTlhO0yo18WFeJYjjZETRoYSWrsTibH_kDC9fNSQSRqjpVLb4nPmUfqfIVK9o7cBUedfx3QhjwPrg4tKVaVA5e6OOwqh2gFPNnzzxfNBTOLeO",
        "Content-Type:application/json"
    )

    @POST("fcm/send")
    fun sendNotification(@Body root: RootModel): Call<ResponseBody>
}