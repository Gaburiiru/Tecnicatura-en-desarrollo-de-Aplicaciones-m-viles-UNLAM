package ar.edu.unlam.chat.repositories.impl

import ar.edu.unlam.chat.entities.Conversation
import ar.edu.unlam.chat.entities.Message
import ar.edu.unlam.chat.exceptions.DatabaseException
import ar.edu.unlam.chat.repositories.ConversationRepository
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase

class ConversationRepositoryImpl : ConversationRepository {

    private val db = Firebase.firestore
    private val collectionName = "conversations"

    private val participantsField = "participantsId"
    private val idField = "id"
    private val lastModifiedField = "lastModified"
    private val messagesField = "messages"
    private val messageDateField = "date"

    override fun findAllForUser(userId: String, onResult: (List<Conversation>) -> Unit) {
        db.collection(collectionName)
            .whereArrayContains(participantsField, userId)
            .orderBy(lastModifiedField, Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { documents ->
                val result = documents.toObjects(Conversation::class.java)
                onResult(result)
            }
            .addOnFailureListener { exception ->
                throw DatabaseException(
                    "Failed when retrieving data from Conversation collection for user $userId",
                    exception
                )
            }
    }

    override fun retrieveConversation(
        id: String,
        onSuccess: (Conversation) -> Unit
    ) {
        db.collection(collectionName)
            .document(id)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    document.toObject(Conversation::class.java)?.let(onSuccess)
                }
            }
            .addOnFailureListener { exception ->
                throw DatabaseException(
                    "Failed when retrieving data from Conversation id $id",
                    exception
                )
            }
    }

    override fun retrieveRealtimeConversation(
        id: String,
        onConversationUpdate: (List<Message>) -> Unit
    ) {
        db.collection(collectionName)
            .document(id)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    throw DatabaseException(
                        "Failed when retrieving realtime from Conversation collection with id $id",
                        error.cause
                    )
                }

                if (snapshot != null) {
                    val result = snapshot.toObject(Conversation::class.java)
                    result?.let {
                        val messages = it.messages.sortedBy { message -> message.date }
                        onConversationUpdate(messages)
                    }
                    return@addSnapshotListener
                }

                onConversationUpdate(listOf())
            }
    }

    override fun addMessage(id: String, message: Message) {
        val documentRef = db.collection(collectionName)
            .document(id);

        db.runTransaction { transaction ->
            transaction.update(documentRef, messagesField, FieldValue.arrayUnion(message))
            transaction.update(documentRef, lastModifiedField, Timestamp.now())
        }
            .addOnFailureListener { exception ->
                throw DatabaseException(
                    "failed sending message to conversation id $id",
                    exception
                )
            }
    }

    override fun startConversation(conversation: Conversation, sent: (String) -> Unit) {
        db.collection(collectionName)
            .add(conversation)
            .addOnSuccessListener { documentReference ->
                sent(documentReference.id)
                documentReference.update(idField, documentReference.id)
            }
            .addOnFailureListener { exception ->
                throw DatabaseException(
                    "failed starting conversation",
                    exception
                )
            }
    }
}