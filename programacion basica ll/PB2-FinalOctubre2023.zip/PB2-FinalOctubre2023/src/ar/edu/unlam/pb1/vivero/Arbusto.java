package ar.edu.unlam.pb1.vivero;

public class Arbusto  {
	
	private final double GANANCIA_ARBUSTO = 1.6;
	 
	public Arbusto(int codigo, String nombre, double precio, int stock) {
	}

}
