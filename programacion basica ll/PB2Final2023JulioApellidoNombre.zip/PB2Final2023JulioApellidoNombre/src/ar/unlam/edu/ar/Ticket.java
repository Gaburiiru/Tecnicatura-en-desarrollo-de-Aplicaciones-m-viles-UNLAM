package ar.unlam.edu.ar;

public class Ticket {
	
	private Integer id;

	public Ticket(Integer id) {
		super();
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
	
	

}
