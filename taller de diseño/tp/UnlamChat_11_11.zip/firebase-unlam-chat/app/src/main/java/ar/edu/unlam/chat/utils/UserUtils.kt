package ar.edu.unlam.chat.utils

import ar.edu.unlam.chat.entities.User
import com.google.firebase.auth.FirebaseAuth

fun User.displayName():String{
    return this.name ?: this.email ?: this.phone ?: this.id
}

fun getLoggedUserId():String{
    FirebaseAuth.getInstance().currentUser?.let {
        return it.uid
    }
    return ""
}

fun isNotCurrentUser(id: String) = FirebaseAuth.getInstance().currentUser?.uid != id

