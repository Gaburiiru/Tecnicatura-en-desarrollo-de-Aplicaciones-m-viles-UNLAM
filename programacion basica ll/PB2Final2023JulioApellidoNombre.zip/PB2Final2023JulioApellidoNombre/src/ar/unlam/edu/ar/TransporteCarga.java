package ar.unlam.edu.ar;

public class TransporteCarga  {

}
