package ar.edu.unlam.chat.services.messages

import com.google.gson.annotations.SerializedName
import java.util.*

data class RootModel(
    @SerializedName("to") val token: String,
    @SerializedName("message_id") val messageId: String,
    val notification: NotificationModel,
    val data: DataModel
)

data class NotificationModel(val title: String, val body: String)
data class DataModel(val text: String, val userName: String)