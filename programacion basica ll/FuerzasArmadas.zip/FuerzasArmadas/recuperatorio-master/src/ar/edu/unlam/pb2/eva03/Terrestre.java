package ar.edu.unlam.pb2.eva03;

public interface Terrestre {
	
	double getVelocidad();
	
	void setVelocidad(double velocidad);
	
}
