package ar.edu.unlam.chat.views.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ar.edu.unlam.chat.databinding.ItemConversationBinding
import ar.edu.unlam.chat.databinding.ItemUserBinding
import ar.edu.unlam.chat.entities.User

class UsersAdapter(private var users: List<User>, val onClick: (User) -> Unit) :
    RecyclerView.Adapter<UsersAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = users[position]
        with(holder.binding) {
            this.userEmail.text = user.email
            this.userName.text = user.name
            this.root.setOnClickListener {
                onClick(user)
            }
        }

    }

    override fun getItemCount() = users.size

    fun changeList(users: List<User>) {
        this.users = users
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root)
}