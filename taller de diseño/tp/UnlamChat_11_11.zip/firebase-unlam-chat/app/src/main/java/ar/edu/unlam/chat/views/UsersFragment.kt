package ar.edu.unlam.chat.views

import android.os.Bundle
import android.view.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import ar.edu.unlam.chat.R
import ar.edu.unlam.chat.databinding.FragmentUsersBinding
import ar.edu.unlam.chat.entities.User
import ar.edu.unlam.chat.services.UserService
import ar.edu.unlam.chat.services.impl.UserServiceImpl
import ar.edu.unlam.chat.views.adapters.UsersAdapter


class UsersFragment : Fragment() {

    private var _binding: FragmentUsersBinding? = null
    private var _userService: UserService? = null
    private var _usersAdapter: UsersAdapter? = null

    private val binding get() = _binding!!
    private val userService get() = _userService!!
    private val usersAdapter get() = _usersAdapter!!
    private var conversationList = listOf<User>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentUsersBinding.inflate(inflater, container, false)
        _userService = UserServiceImpl
        _usersAdapter = UsersAdapter(conversationList) {
            onUserClick(it)
        }

        createMenu()
        return binding.root

    }

    private fun createMenu() {
        val menuHost: MenuHost = requireActivity()

        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                // Add menu items here
                menuInflater.inflate(R.menu.menu_users, menu)

                val searchItem = menu.findItem(R.id.search)
                val searchView = searchItem.actionView as SearchView
                searchView.queryHint = getString(R.string.search_hint)

                searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

                    override fun onQueryTextChange(newText: String): Boolean {
                        if (newText.length > 3) {
                            searchUser(newText)
                        }
                        return true
                    }

                    override fun onQueryTextSubmit(query: String): Boolean {
                        searchUser(query)
                        return true
                    }

                })

            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return true
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.usersList.adapter = usersAdapter
        binding.usersList.layoutManager = LinearLayoutManager(requireActivity())
        userService.findAll {
            usersAdapter.changeList(it)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        _usersAdapter = null
        _userService = null
    }

    private fun searchUser(text: String) {
        userService.searchUser(text) {
            usersAdapter.changeList(it)
        }
    }

    private fun onUserClick(user: User) {
        val action = UsersFragmentDirections.actionUsersFragmentToSingleConversation(
            conversationId = null,
            userId = user.id,
            userName = user.name
        )
        findNavController().navigate(action)
    }
}