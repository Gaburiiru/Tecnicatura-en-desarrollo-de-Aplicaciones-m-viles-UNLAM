package ar.edu.unlam.chat.repositories

import ar.edu.unlam.chat.entities.User

interface UserRepository {
    fun get(id: String, onSuccess: (User) -> Unit)
    fun findAll(text: String, onSuccess: (List<User>) -> Unit)
    fun findAll(onSuccess: (List<User>) -> Unit)
    fun save(user: User)
    fun updateToken(userId: String, token: String)
}