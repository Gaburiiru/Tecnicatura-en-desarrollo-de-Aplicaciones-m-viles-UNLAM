package ar.edu.unlam.chat.views

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import ar.edu.unlam.chat.databinding.FragmentConversationsBinding
import ar.edu.unlam.chat.entities.Conversation
import ar.edu.unlam.chat.services.ConversationService
import ar.edu.unlam.chat.services.impl.ConversationServiceImpl
import ar.edu.unlam.chat.utils.getLoggedUserId
import ar.edu.unlam.chat.utils.isNotCurrentUser
import ar.edu.unlam.chat.views.adapters.ConversationsListAdapter

class ConversationsFragment : Fragment() {

    private var _binding: FragmentConversationsBinding? = null
    private var _conversationService: ConversationService? = null
    private var _conversationAdapter: ConversationsListAdapter? = null

    private val binding get() = _binding!!
    private val conversationService get() = _conversationService!!
    private val conversationAdapter get() = _conversationAdapter!!
    private var conversationList = listOf<Conversation>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentConversationsBinding.inflate(inflater, container, false)
        _conversationService = ConversationServiceImpl
        _conversationAdapter = ConversationsListAdapter(conversationList) {
            onConversationClick(it)
        }
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.conversationsList.adapter = conversationAdapter
        binding.conversationsList.layoutManager = LinearLayoutManager(requireActivity())
        conversationService.getUserConversations(getLoggedUserId()) {
            conversationAdapter.changeList(it)
        }
        binding.fab.setOnClickListener {
            findNavController().navigate(ConversationsFragmentDirections.actionConversationListToUsersFragment())
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        _conversationAdapter = null
        _conversationService = null
    }

    private fun onConversationClick(conversation: Conversation) {
        val user = conversation.participants.find { isNotCurrentUser(it.id) }
        val action = ConversationsFragmentDirections.actionConversationListToSingleConversation(
            conversationId = conversation.id?:"",
            userId = null,
            userName = user?.name
        )
        findNavController().navigate(action)
    }
}