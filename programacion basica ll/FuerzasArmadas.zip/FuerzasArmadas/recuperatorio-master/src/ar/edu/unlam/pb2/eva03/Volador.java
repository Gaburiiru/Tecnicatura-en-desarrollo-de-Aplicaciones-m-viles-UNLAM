package ar.edu.unlam.pb2.eva03;

public interface Volador {

	double getAltura();

	void setAltura(double altura);

}
