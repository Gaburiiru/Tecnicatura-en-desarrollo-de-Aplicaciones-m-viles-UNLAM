package ar.edu.unlam.pb1.vivero;

public class Venta {

	private Integer id;
	private Integer unidades;
	private Planta planta;
	public Double precioUnitario; // Precio final de la planta al momento de realizar la venta
}
