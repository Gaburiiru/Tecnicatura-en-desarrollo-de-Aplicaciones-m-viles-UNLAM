package ar.edu.unlam.chat.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ar.edu.unlam.chat.R
import ar.edu.unlam.chat.repositories.UserRepository
import ar.edu.unlam.chat.repositories.impl.UserRepositoryImpl
import ar.edu.unlam.chat.utils.getLoggedUserId
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.util.*


class NotificationService : FirebaseMessagingService() {

    val userRepository: UserRepository = UserRepositoryImpl()

    override fun onNewToken(token: String) {
        userRepository.updateToken(getLoggedUserId(),token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d(TAG, "From: ${remoteMessage.from}")

        if (remoteMessage.data.isNotEmpty()) {
            Log.d(TAG, "Message data payload: ${remoteMessage.data}")
        }

        remoteMessage.notification?.let {
            Log.d(TAG, "Message Notification Body: ${it.body}")
            val channelId = getString(R.string.default_notification_channel_id)
            val notificationBuilder = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(it.title)
                .setContentText(it.body)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)


            with(NotificationManagerCompat.from(this)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        channelId,
                        getString(R.string.default_notification_channel_text),
                        NotificationManager.IMPORTANCE_HIGH
                    )
                    this.createNotificationChannel(channel)
                }
                notify(Random().nextInt(), notificationBuilder.build())
            }
        }


    }

    companion object{
        val TAG = NotificationService::class.simpleName
    }
}