package ar.edu.unlam.chat.views

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import ar.edu.unlam.chat.databinding.FragmentSingleConversationBinding
import ar.edu.unlam.chat.entities.Message
import ar.edu.unlam.chat.services.ConversationService
import ar.edu.unlam.chat.services.impl.ConversationServiceImpl
import ar.edu.unlam.chat.utils.getLoggedUserId
import ar.edu.unlam.chat.views.adapters.ConversationAdapter

class SingleConversationFragment : Fragment() {

    private var _binding: FragmentSingleConversationBinding? = null
    private var _conversationService: ConversationService? = null
    private var _conversationAdapter: ConversationAdapter? = null

    private val binding get() = _binding!!
    private val conversationService get() = _conversationService!!
    private val conversationAdapter get() = _conversationAdapter!!
    private var messagesList = listOf<Message>()
    private val args: SingleConversationFragmentArgs by navArgs()
    private lateinit var conversationId: String
    private lateinit var userId: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSingleConversationBinding.inflate(inflater, container, false)
        _conversationService = ConversationServiceImpl
        _conversationAdapter = ConversationAdapter(messagesList)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        args.conversationId?.let { conversationId ->
            connectToConversation(conversationId)
        }

        args.userId?.let {
            userId = it
        }

        setActionBarTitle()

        binding.messagesList.layoutManager = LinearLayoutManager(requireActivity())
        binding.messagesList.adapter = conversationAdapter

        binding.sendMessage.setOnClickListener {
            if (this::userId.isInitialized) {
                startConversation()
            } else {
                sendMessage()
            }
            binding.messageText.setText("")
        }

    }

    private fun connectToConversation(conversationId: String) {
        this.conversationId = conversationId
        conversationService.connectToConversation(conversationId) {
            conversationAdapter.changeList(it)
        }
    }

    private fun startConversation() {
        conversationService.startConversation(
            getLoggedUserId(),
            this.userId,
            binding.messageText.text.toString()
        ) {
            connectToConversation(it)
        }
    }

    private fun sendMessage() {
        conversationService.sendMessage(
            getLoggedUserId(),
            conversationId,
            binding.messageText.text.toString()
        )
    }

    private fun setActionBarTitle(){
        (requireActivity() as AppCompatActivity).supportActionBar?.title = args.userName ?: ""
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}