package ar.edu.unlam.chat.repositories

import ar.edu.unlam.chat.entities.Conversation
import ar.edu.unlam.chat.entities.Message

interface ConversationRepository {
    fun findAllForUser(userId: String, onResult: (List<Conversation>) -> Unit)
    fun retrieveRealtimeConversation(id: String, onConversationUpdate: (List<Message>) -> Unit)
    fun retrieveConversation(id: String, onSuccess: (Conversation) -> Unit)
    fun addMessage(id: String, message: Message)
    fun startConversation(conversation: Conversation, sent: (String) -> Unit)

}