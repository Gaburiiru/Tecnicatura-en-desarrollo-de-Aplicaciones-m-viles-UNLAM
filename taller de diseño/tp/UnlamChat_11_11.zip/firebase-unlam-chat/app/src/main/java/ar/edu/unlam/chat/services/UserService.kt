package ar.edu.unlam.chat.services

import ar.edu.unlam.chat.entities.User

interface UserService {
    fun searchUser(text: String, onSuccess: (List<User>) -> Unit)
    fun getUser(id: String, onSuccess: (User) -> Unit)
    fun findAll(onSuccess: (List<User>) -> Unit)
    fun save(user: User)
    fun updateToken(token: String)

}