package ar.edu.unlam.pb1.vivero;

public class Hierba {

	private final double gananciaHierbaMata = 1.2;

	public Hierba(int codigo, String nombre, double precio, int stock) {
	}
}
