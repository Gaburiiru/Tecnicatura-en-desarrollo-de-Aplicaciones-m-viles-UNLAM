package ar.edu.unlam.chat

import android.app.Application
import android.util.Log
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.ktx.messaging

class ChatUnlamApp : Application() {

    override fun onCreate() {
        Firebase.messaging.subscribeToTopic(getString(R.string.new_message_topic))
            .addOnCompleteListener { task ->

                if (!task.isSuccessful) {
                    Log.e(TAG, "fail subscribing to new message topic")
                }
                Log.d(TAG, "success when subscribing to new message topic")
            }
        super.onCreate()
    }

    companion object {
        val TAG = ChatUnlamApp::class.simpleName
    }
}