package ar.edu.unlam.chat.services.impl

import android.util.Log
import ar.edu.unlam.chat.entities.Conversation
import ar.edu.unlam.chat.entities.Message
import ar.edu.unlam.chat.repositories.ConversationRepository
import ar.edu.unlam.chat.repositories.UserRepository
import ar.edu.unlam.chat.repositories.impl.ConversationRepositoryImpl
import ar.edu.unlam.chat.repositories.impl.UserRepositoryImpl
import ar.edu.unlam.chat.services.ConversationService
import ar.edu.unlam.chat.services.messages.MessageClient
import ar.edu.unlam.chat.utils.displayName
import ar.edu.unlam.chat.utils.isNotCurrentUser
import com.google.firebase.Timestamp
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.RemoteMessage

object ConversationServiceImpl : ConversationService {

    private val conversationRepository: ConversationRepository = ConversationRepositoryImpl()
    private val userRepository: UserRepository = UserRepositoryImpl()

    override fun startConversation(
        initiatorId: String,
        toUserId: String,
        text: String,
        onStarted: (String) -> Unit
    ) {
        userRepository.get(initiatorId) { initiatorUser ->
            userRepository.get(toUserId) { toUser ->
                val message =
                    Message(
                        text,
                        initiatorUser.id,
                        initiatorUser.displayName(),
                        Timestamp.now()
                    )
                conversationRepository.startConversation(
                    Conversation(
                        listOf(message),
                        listOf(initiatorUser, toUser),
                        listOf(initiatorId, toUserId),
                        Timestamp.now()
                    )
                ) { conversationId ->
                    onStarted(conversationId)
                }
            }
        }
    }

    override fun connectToConversation(id: String, onUpdateConversation: (List<Message>) -> Unit) {
        conversationRepository.retrieveRealtimeConversation(id, onUpdateConversation)
    }

    override fun sendMessage(
        userId: String,
        conversationId: String,
        text: String
    ) {
        userRepository.get(userId) { initiatorUser ->
            val message =
                Message(text, initiatorUser.id, initiatorUser.displayName(), Timestamp.now())
            conversationRepository.addMessage(conversationId, message)
            conversationRepository.retrieveConversation(conversationId) { conversation ->
                conversation.participantsId.find { id-> isNotCurrentUser(id) }?.let {
                    userRepository.get(it) { notifiedUser ->
                        notifiedUser.token?.let { token ->
                            MessageClient.send(token, text, initiatorUser.displayName())
                        }
                    }
                }
            }
        }
    }

    override fun getUserConversations(id: String, onSuccess: (List<Conversation>) -> Unit) {
        conversationRepository.findAllForUser(id, onSuccess)
    }

    val TAG = ConversationServiceImpl::class.simpleName
}