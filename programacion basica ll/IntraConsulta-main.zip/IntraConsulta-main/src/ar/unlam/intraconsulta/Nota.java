package ar.unlam.intraconsulta;

public class Nota {
 
	private Integer valor;
	
	public Nota() {
		
	};
	
	public Nota(Integer valor) {
		this.valor = valor;
	};
	


	public Integer getValor() {
		return valor;
	}

	public void setValor(Integer valor) {
		this.valor = valor;
	}
	
	

}
