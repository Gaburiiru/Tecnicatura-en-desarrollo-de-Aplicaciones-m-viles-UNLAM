package ar.edu.unlam.chat.services.impl

import ar.edu.unlam.chat.entities.User
import ar.edu.unlam.chat.repositories.UserRepository
import ar.edu.unlam.chat.repositories.impl.UserRepositoryImpl
import ar.edu.unlam.chat.services.UserService
import ar.edu.unlam.chat.utils.getLoggedUserId

object UserServiceImpl : UserService {

    private val userRepository: UserRepository = UserRepositoryImpl()

    override fun searchUser(text: String, onSuccess: (List<User>) -> Unit) {
        userRepository.findAll(text, onSuccess)
    }

    override fun getUser(id: String, onSuccess: (User) -> Unit) {
        userRepository.get(id, onSuccess)
    }

    override fun findAll(onSuccess: (List<User>) -> Unit) {
        userRepository.findAll(onSuccess)
    }

    override fun save(user: User) {
        userRepository.save(user)
    }

    override fun updateToken(token: String) {
        userRepository.updateToken(getLoggedUserId(), token)
    }
}