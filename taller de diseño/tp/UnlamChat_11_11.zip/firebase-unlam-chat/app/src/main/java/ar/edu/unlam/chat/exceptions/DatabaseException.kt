package ar.edu.unlam.chat.exceptions

class DatabaseException(override val message: String, throwable: Throwable?) : Throwable(throwable)