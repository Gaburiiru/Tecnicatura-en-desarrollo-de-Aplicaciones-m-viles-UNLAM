package ar.edu.unlam.pb1.vivero;

public interface Florales {

	void florar();
	void producirFrutos();
	
}
