package ar.edu.unlam.chat.entities

data class User(
    val id: String = "",
    val name: String? = null,
    val email: String? = null,
    val phone: String? = null,
    val token: String? = null
)
