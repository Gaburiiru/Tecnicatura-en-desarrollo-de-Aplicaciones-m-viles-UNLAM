package ar.edu.unlam.pb2.eva03;

public interface Acuatico {

	double getProfundidad();
	
	void setProfundidad(double profundidad);

}
