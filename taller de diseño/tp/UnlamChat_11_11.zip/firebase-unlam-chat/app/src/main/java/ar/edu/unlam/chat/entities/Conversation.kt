package ar.edu.unlam.chat.entities

import com.google.firebase.Timestamp

data class Conversation(
    val messages: List<Message> = listOf(),
    val participants: List<User> = listOf(),
    val participantsId: List<String> = listOf(),
    val lastModified: Timestamp = Timestamp.now(),
    val id: String? = null
)
