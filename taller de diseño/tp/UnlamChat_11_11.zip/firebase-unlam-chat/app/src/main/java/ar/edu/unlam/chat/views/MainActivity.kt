package ar.edu.unlam.chat.views

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import ar.edu.unlam.chat.R
import ar.edu.unlam.chat.databinding.ActivityMainBinding
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.logEvent
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.crashlytics.ktx.crashlytics
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.ktx.remoteConfig
import com.google.firebase.remoteconfig.ktx.remoteConfigSettings


class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private lateinit var firebaseAnalytics: FirebaseAnalytics
    private lateinit var remoteConfig: FirebaseRemoteConfig
    private lateinit var button_mensaje: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)


        // Creates a button that mimics a crash when pressed
        // Creates a button that mimics a crash when pressed
        val crashButton = Button(this)
        crashButton.text = "testeo Crash"
        crashButton.setOnClickListener(View.OnClickListener {
            throw RuntimeException("testeo Crash") // Force a crash
        })

        addContentView(
            crashButton, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        Firebase.crashlytics.log("soy un mensage")


        //analytics
        firebaseAnalytics.logEvent("hola baby") {
            param("inserte texto", "hola")
        }
        val parameters = Bundle().apply {
            this.putString("soy un string", "juanCarlos")
        }
        firebaseAnalytics.setDefaultEventParameters(parameters)

        //remote config
        val configSettings = remoteConfigSettings {
            minimumFetchIntervalInSeconds = 3600
            fetchTimeoutInSeconds = 10
        }
        //cuando ande la aplicacion hay que utilizar la id de los parametros
        remoteConfig.setConfigSettingsAsync(configSettings)
        val defaults = mapOf(
            "primera_conversacion" to "true",
            "conversacion_text" to "text"
        )
        Firebase.remoteConfig.setDefaultsAsync(defaults)

        button_mensaje.visibility = View.INVISIBLE
        val addOnCompleteListener = remoteConfig.fetchAndActivate().addOnCompleteListener { task ->

            if (task.isSuccessful) {
                val primera_conversacion = Firebase.remoteConfig.getBoolean("primera_conversacion")
                val conversacion_text = Firebase.remoteConfig.getString("conversacion_text")

                if (primera_conversacion) {
                    button_mensaje.visibility = View.VISIBLE
                }
                button_mensaje.text = conversacion_text
            }
        }
        FirebaseDatabase.getInstance().reference
        val database = Firebase.database
        val myRef = database.getReference("message")

        myRef.setValue("Hello, World!")
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            R.id.action_logout -> signOut()
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }


    private fun signOut(): Boolean {
        FirebaseAuth.getInstance().signOut()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
        return true
    }
}