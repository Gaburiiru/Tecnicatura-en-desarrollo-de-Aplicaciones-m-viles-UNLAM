package ar.edu.unlam.chat.views.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ar.edu.unlam.chat.databinding.ItemMyMessageBinding
import ar.edu.unlam.chat.databinding.ItemReceivedMessageBinding
import ar.edu.unlam.chat.entities.Message
import ar.edu.unlam.chat.utils.isNotCurrentUser

class ConversationAdapter(private var list: List<Message>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val myMessage = 1
    private val receivedMessage = 2
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (myMessage == viewType) {
            val binding =
                ItemMyMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            MyMessageViewHolder(binding)
        } else {
            val binding = ItemReceivedMessageBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            ReceivedMessageViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = list[position]
        if (isNotCurrentUser(message.userId)) {
            val view = holder as ReceivedMessageViewHolder
            view.binding.text.text = message.text
        } else {
            val view = holder as MyMessageViewHolder
            view.binding.text.text = message.text
        }


    }

    override fun getItemCount() = list.size

    override fun getItemViewType(position: Int) =
        if (isNotCurrentUser(list[position].userId)) {
            receivedMessage
        } else {
            myMessage
        }


    fun changeList(list: List<Message>) {
        this.list = list
        notifyDataSetChanged()
    }

    class MyMessageViewHolder(val binding: ItemMyMessageBinding) :
        RecyclerView.ViewHolder(binding.root)

    class ReceivedMessageViewHolder(val binding: ItemReceivedMessageBinding) :
        RecyclerView.ViewHolder(binding.root)
}