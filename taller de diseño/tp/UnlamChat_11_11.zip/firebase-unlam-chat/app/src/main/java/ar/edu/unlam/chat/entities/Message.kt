package ar.edu.unlam.chat.entities

import com.google.firebase.Timestamp

data class Message(
    val text: String = "",
    val userId: String = "",
    val userName: String = "",
    val date: Timestamp = Timestamp.now()
)
