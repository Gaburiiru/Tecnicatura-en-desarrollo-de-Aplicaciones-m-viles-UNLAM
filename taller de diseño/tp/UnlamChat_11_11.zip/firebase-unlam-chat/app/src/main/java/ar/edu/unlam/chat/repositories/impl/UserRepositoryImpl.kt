package ar.edu.unlam.chat.repositories.impl

import ar.edu.unlam.chat.entities.User
import ar.edu.unlam.chat.exceptions.DatabaseException
import ar.edu.unlam.chat.repositories.UserRepository
import ar.edu.unlam.chat.utils.getLoggedUserId
import ar.edu.unlam.chat.utils.isNotCurrentUser
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class UserRepositoryImpl : UserRepository {

    private val db = Firebase.firestore
    private val collectionName = "users"
    private val nameField = "name"
    private val emailField = "email"
    private val phoneField = "phone"
    private val idField = "id"
    private val tokenField = "token"


    override fun get(id: String, onSuccess: (User) -> Unit) {
        db.collection(collectionName)
            .document(id)
            .get()
            .addOnSuccessListener { document ->
                document.toObject(User::class.java)?.let { user ->
                    onSuccess(user)
                }
            }
            .addOnFailureListener { exception ->
                throw DatabaseException("Fail retrieving user with id $id", exception)
            }
    }

    override fun findAll(text: String, onSuccess: (List<User>) -> Unit) {
        retrieveByEmail(text) { byEmailUsers ->
            retrieveByName(text) { byNameUsers ->
                byEmailUsers.addAll(byNameUsers)
                onSuccess(byEmailUsers.filter { isNotCurrentUser(it.id) }.toList())
            }
        }
    }

    override fun findAll(onSuccess: (List<User>) -> Unit) {
        db.collection(collectionName)
            .whereNotEqualTo(idField, getLoggedUserId())
            .get()
            .addOnSuccessListener { documents ->
                val result = documents.toObjects(User::class.java)
                onSuccess(result)
            }
    }

    override fun save(user: User) {
        db.collection(collectionName)
            .document(user.id)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    db.collection(collectionName)
                        .document(user.id)
                        .update(
                            mapOf(
                                emailField to user.email,
                                nameField to user.name,
                                phoneField to user.phone
                            )
                        )
                        .addOnFailureListener {
                            throw DatabaseException("fail updating user ${user.id}", it)
                        }
                } else {
                    db.collection(collectionName)
                        .document(user.id)
                        .set(user)
                        .addOnFailureListener {
                            throw DatabaseException("fail creating user ${user.id}", it)
                        }

                }
            }
            .addOnFailureListener {
                throw DatabaseException("fail getting user ${user.id}", it)
            }

    }

    override fun updateToken(userId: String, token: String) {
        db.collection(collectionName)
            .document(userId)
            .update(tokenField, token)
    }

    private fun retrieveByName(text: String, onSuccess: (MutableCollection<User>) -> Unit) {
        db.collection(collectionName)
            .whereGreaterThanOrEqualTo(nameField, text)
            .whereLessThanOrEqualTo(nameField, text)
            .get()
            .addOnSuccessListener { document ->
                val users = document.toObjects(User::class.java)
                onSuccess(users)
            }
    }

    private fun retrieveByEmail(text: String, onSuccess: (MutableCollection<User>) -> Unit) {
        db.collection(collectionName)
            .whereGreaterThanOrEqualTo(emailField, text)
            .whereLessThanOrEqualTo(emailField, text)
            .get()
            .addOnSuccessListener { document ->
                val users = document.toObjects(User::class.java)
                onSuccess(users)
            }
    }
}