package ar.edu.unlam.chat.services.messages

import android.util.Log
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*

/**
 * DISCLAIMER:
 * Esto no es un buena practica, el solo hecho de utilizar esta llamada a la api de firebase expone datos sensibles a un atacante
 * Recordemos que cualquier usuario puede descompilar un APK y por consecuencia obtener esta información
 */
object MessageClient {

    private val BASE_URL = "https://fcm.googleapis.com/"
    private var retrofit: Retrofit? = null

    fun getClient(): Retrofit? {
        if (retrofit == null) {
            retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return retrofit
    }

    fun send(token: String, body: String, from: String) {
        getClient()?.create(MessageInterface::class.java)?.let { apiService ->
            val rootModel =
                RootModel(
                    token,
                    UUID.randomUUID().toString(),
                    NotificationModel("Nuevo mensaje de $from", body),
                    DataModel(body, from)
                )

            apiService.sendNotification(rootModel).enqueue(object : Callback<ResponseBody> {
                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: Response<ResponseBody>
                ) {
                    if(response.isSuccessful){
                        Log.d(TAG, "Successfully notification send by using retrofit.")
                    }else{
                        Log.e(TAG, "Fail sending notification. with message ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Log.e(TAG, "Fail sending notification.")
                }

            })
        }

    }

    val TAG = MessageClient::class.simpleName
}